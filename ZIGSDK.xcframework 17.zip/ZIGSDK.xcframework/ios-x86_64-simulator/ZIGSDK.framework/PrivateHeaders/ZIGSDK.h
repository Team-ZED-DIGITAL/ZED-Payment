//
//  ZIGSDKiOS.h
//  ZIGSDKiOS
//
//  Created by Ashok on 2/13/25.
//

#import <Foundation/Foundation.h>

//! Project version number for ZIGSDKiOSiOS.
FOUNDATION_EXPORT double ZIGSDKiOSVersionNumber;

//! Project version string for ZIGSDKiOSiOS.
FOUNDATION_EXPORT const unsigned char ZIGSDKiOSVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ZIGSDKiOSiOS/PublicHeader.h>


